BALANCE - visual assets at 1080p scale
======================================

Scale
- Backgrounds: 1920x1080 (each art pixel = 6x6 screen pixels).
- Everything else: x5 (each art pixel = 5x5 screen pixels). This is the size things appear on a
  1920x1080 screen in the game, kept to a whole number so pixels stay square.
- Scale with "nearest neighbour" / "point" filtering in your engine (never bilinear).

01_backgrounds   6 animated skies: calm, unease, sadness, anxiety, emptiness, dawn.
                 .gif = animated loop (48 frames, 10 fps, loops seamlessly)
                 .png = still image, *_frames/ = the 48 frames as separate PNGs.
                 Background follows the island tilt: calm < 4 deg, unease < 10, sadness < 17,
                 anxiety < 24, emptiness above. Dawn = title screen / level complete.

02_islands       Each emotion has 4 islands: 6_blocks, 3_blocks, 2_blocks (with a dark slot for the
                 blocks) and plain (no blocks, used in the sky levels).
                 Sizes: 6_blocks 980x390, 3_blocks 560x280, 2_blocks 420x240, plain 980x390.
                 Blocks go at x = 70 + 140*k, y = 15 (k = 0,1,2...), all island sizes.
                 Plain island: the walkable grass is at y = 30.
                 Rotation pivot: horizontal centre, y = 15 (top of the block row).

03_blocks        140x80. 9 colours, each normal + _glow (lit). Grey = idle, red = mistake.

04_character     character.png 145x250 and character_dizzy.png 190x240 (feet on the bottom row).
                 rig_parts/  the layers the game moves to animate him (same 145x250 grid, stack them
                             in this order: arm_back, leg_back, leg_front, body, head, arm_front).
                 animations/ ready-made poses, 165x290, feet on the bottom row, body centre at x = 80:
                             idle (4), blink, run (4), jump_up, jump_fall, land, crouch, balance,
                             slide (2), celebrate (2), wave (2), look_up, flinch.
                             sheet_*.png = the same frames side by side.
                 Suggested speeds: idle 4 fps, run 1 frame every 7 px moved, others 8-12 fps.

05_orbs          95x95 sky orbs, 8 colours, normal + _lit. ring_effect/ = 6-frame ring that expands
                 from an orb when it lights up.

06_ui            logo, buttons (normal + selected), on-screen messages, "YOU FEEL" labels,
                 intrusive thoughts, panel (and a 9-slice: 5px x5 border), stability meter segments,
                 sequence dots, timer bar, fullscreen and sound icons, touch buttons.

07_effects       dust / spark particles (one pixel each) and the contact shadow.

08_font          Press Start 2P (SIL Open Font License, free to use and ship with your game).
